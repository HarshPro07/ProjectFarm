function changeLanguage(language) {
    
    const content = {
        en: {
          title: "🌾 Farmer's Portal 🌾",
          heroText: "Empowering Farmers Through Technology",
          feature1: "Find Nearby Market",
          feature2: "Learn New Techniques",
          // Add more text elements for English
        },
        mr: {
          title: "🌾 शेतकऱ्यांचा पोर्टल 🌾",
          heroText: "तंत्रज्ञानाद्वारे शेतकऱ्यांना सशक्त बनवित आहे",
          feature1: "जवळील बाजार शोधा",
          feature2: "नवीन तंत्रज्ञान शिका",
          // Add more text elements for Marathi
        },
      };
      
  
    // Change content based on selected language
    document.getElementById('main-title').textContent = content[language].title;
    document.getElementById('hero-text').textContent = content[language].heroText;
    
    // You can add more elements here for other sections of your page as well

    
  }
  